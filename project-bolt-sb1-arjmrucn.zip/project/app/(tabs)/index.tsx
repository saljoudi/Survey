import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { router } from 'expo-router';
import { useSurveyStore } from '@/stores/surveyStore';
import { ArrowRight } from 'lucide-react-native';

export default function SurveysScreen() {
  const surveys = useSurveyStore((state) => state.surveys);

  const renderSurveyItem = ({ item }) => (
    <TouchableOpacity
      style={styles.surveyCard}
      onPress={() => router.push(`/survey/${item.id}`)}
    >
      <View style={styles.cardContent}>
        <Text style={styles.surveyTitle}>{item.title}</Text>
        <Text style={styles.surveyDescription}>{item.description}</Text>
        <View style={styles.surveyMeta}>
          <Text style={styles.questionCount}>
            {item.questions.length} questions
          </Text>
          <Text style={styles.estimatedTime}>~{item.questions.length * 2} min</Text>
        </View>
      </View>
      <ArrowRight size={24} color="#0ea5e9" />
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Available Surveys</Text>
        <Text style={styles.subtitle}>Select a survey to begin</Text>
      </View>

      <FlatList
        data={surveys}
        renderItem={renderSurveyItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#fff',
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 28,
    color: '#000',
    marginBottom: 8,
  },
  subtitle: {
    fontFamily: 'Inter_400Regular',
    fontSize: 16,
    color: '#666',
  },
  list: {
    padding: 20,
    gap: 16,
  },
  surveyCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#eee',
  },
  cardContent: {
    flex: 1,
    gap: 8,
  },
  surveyTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 18,
    color: '#000',
  },
  surveyDescription: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: '#666',
  },
  surveyMeta: {
    flexDirection: 'row',
    gap: 16,
    marginTop: 8,
  },
  questionCount: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
    color: '#0ea5e9',
  },
  estimatedTime: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
    color: '#0ea5e9',
  },
});