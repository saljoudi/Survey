import { create } from 'zustand';

interface Survey {
  id: string;
  title: string;
  description: string;
  questions: Question[];
}

interface Question {
  id: string;
  text: string;
  type: 'text' | 'rating' | 'choice';
  options?: string[];
}

interface SurveyResponse {
  id: string;
  surveyId: string;
  userId: string;
  answers: Answer[];
  completedAt: string;
}

interface Answer {
  questionId: string;
  value: string;
}

interface SurveyState {
  surveys: Survey[];
  responses: SurveyResponse[];
  addResponse: (response: SurveyResponse) => void;
  getUserResponses: (userId: string) => SurveyResponse[];
}

const mockSurveys: Survey[] = [
  {
    id: '1',
    title: 'Customer Satisfaction',
    description: 'Help us improve our products and services',
    questions: [
      {
        id: '1-1',
        text: 'How satisfied are you with our product?',
        type: 'rating',
      },
      {
        id: '1-2',
        text: 'Would you recommend our product to others?',
        type: 'rating',
      },
      {
        id: '1-3',
        text: 'What features would you like to see improved?',
        type: 'text',
      },
    ],
  },
  {
    id: '2',
    title: 'Product Feedback',
    description: 'Share your thoughts about our latest features',
    questions: [
      {
        id: '2-1',
        text: 'How often do you use our product?',
        type: 'choice',
        options: ['Daily', 'Weekly', 'Monthly', 'Rarely'],
      },
      {
        id: '2-2',
        text: 'What is your favorite feature?',
        type: 'text',
      },
      {
        id: '2-3',
        text: 'What is your least favorite feature?',
        type: 'text',
      },
    ],
  },
];

export const useSurveyStore = create<SurveyState>((set, get) => ({
  surveys: mockSurveys,
  responses: [],

  addResponse: (response) => {
    set((state) => ({
      responses: [...state.responses, response],
    }));
  },

  getUserResponses: (userId) => {
    return get().responses.filter((response) => response.userId === userId);
  },
}));