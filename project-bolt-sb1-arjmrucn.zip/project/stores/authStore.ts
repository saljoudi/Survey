import { create } from 'zustand';
import * as SecureStore from 'expo-secure-store';

interface User {
  id: string;
  username: string;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<void>;
  signup: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

// In a real app, this would be your backend API
const mockUsers = new Map<string, { id: string; password: string }>();

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,

  login: async (username: string, password: string) => {
    const user = mockUsers.get(username);
    if (!user || user.password !== password) {
      throw new Error('Invalid credentials');
    }

    const userData = { id: user.id, username };
    await SecureStore.setItemAsync('user', JSON.stringify(userData));
    
    set({ user: userData, isAuthenticated: true });
  },

  signup: async (username: string, password: string) => {
    if (mockUsers.has(username)) {
      throw new Error('Username already exists');
    }

    const userId = Math.random().toString(36).substr(2, 9);
    mockUsers.set(username, { id: userId, password });

    const userData = { id: userId, username };
    await SecureStore.setItemAsync('user', JSON.stringify(userData));
    
    set({ user: userData, isAuthenticated: true });
  },

  logout: async () => {
    await SecureStore.deleteItemAsync('user');
    set({ user: null, isAuthenticated: false });
  },
}));